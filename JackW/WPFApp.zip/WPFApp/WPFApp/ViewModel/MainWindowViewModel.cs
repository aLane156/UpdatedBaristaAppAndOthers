﻿using System;
using System.Windows.Input;

namespace WPFApp.ViewModel
{
    public class MainWindowViewModel : BaseViewModel
    {
        public MainWindowViewModel() 
        {
            Num = 0;
            Increment = new RelayCommand(IncrementNum);
        }

        public ICommand Increment { get; init; }

        public int Num 
        {
            get => _num;
            set 
            { 
                _num = value;
                NotifyPropertyChanged(nameof(Num));
            }
        }

        private int _num;

        private void IncrementNum (object obj)
        {
            Num++;
        }
    }
}
